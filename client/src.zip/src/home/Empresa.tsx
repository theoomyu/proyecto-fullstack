import Heading from "../components/Headings"

export const Empresa = () => {
    return (
        <section className="py-20 text-background/75 
            bg-linear-to-br from-primary via-primary/85 to-primary/95">
            <div className="max-w-7xl mx-auto px-3">
                <Heading level={2}>Empresa</Heading>
                <div className="grid md:grid-cols-3 gap-8">
                    <div className="col-span-2">
                        <Heading level={3} className="border-s-2 border-accent ps-5 mt-1">Historia de la empresa</Heading>
                        <p>Loki nació de la visión compartida de un grupo de desarrolladores apasionados por el inmenso potencial de la inteligencia artificial. En nuestros inicios, identificamos que muchas empresas luchaban por integrar estas nuevas tecnologías en sus flujos de trabajo tradicionales, limitando seriamente su capacidad de innovación. Decidimos construir el puente definitivo entre la ingeniería de software robusta y la inteligencia generativa.</p>
                        <p>Con el rápido avance de los modelos de lenguaje y el machine learning, evolucionamos rápidamente nuestra arquitectura tecnológica para ofrecer soluciones completamente a medida. Pasamos de ser un pequeño equipo de consultoría a un laboratorio de desarrollo full-stack, donde cada aplicación es diseñada desde sus cimientos para automatizar procesos complejos y procesar grandes volúmenes de datos en tiempo real.</p>
                        <p>Hoy en día, nos enorgullece ser un motor de cambio en la creación de ecosistemas digitales inteligentes. Nuestro equipo continúa empujando los límites del desarrollo tecnológico, colaborando estrechamente con organizaciones visionarias para transformar sus ideas más audaces en plataformas escalables, eficientes y listas para liderar la nueva era digital.</p>
                    </div>
                    <div className="border border-background/25 p-7 rounded-2xl
                        bg-linear-to-br from-background/14 via-background/7 to-accent/20
                        shadow-lg">
                        <Heading level={3} className="border-s-2 border-accent ps-5 mt-1">Misión</Heading>
                        <p>Desarrollar software ágil e inteligente que resuelva desafíos complejos, optimice flujos de trabajo y genere un crecimiento comercial sostenible para nuestros clientes.</p>
                        <Heading level={3} className="border-s-2 border-accent ps-5 mt-1">Visión</Heading>
                        <p>Ser el socio tecnológico líder en desarrollo inteligente a nivel regional, reconocidos por nuestra innovación constante y excelencia técnica.</p>
                    </div>
                </div>
            </div>
        </section>
    )
}
