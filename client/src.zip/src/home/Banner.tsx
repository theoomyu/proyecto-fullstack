import slide1 from "../assets/banner/slide1.jpg"
import slide2 from "../assets/banner/slide2.jpg"
import slide3 from "../assets/banner/slide3.jpg"

import { Swiper, SwiperSlide, useSwiper } from "swiper/react"
import { Autoplay, EffectFade, Pagination } from "swiper/modules"

import "swiper/css"
import "swiper/css/pagination"
import "swiper/css/effect-fade"
import { Link } from "react-router"

const SLIDES = [
  [
    slide1,
    "Software + IA",
    "Convertimos ideas en",
    "productos inteligentes.",
    "Diseñamos soluciones digitales donde software, experiencia e inteligencia artificial trabajan juntas para resolver desafíos reales.",
    "Explorar servicios"
  ],
  [
    slide2,
    "Diseño + Tecnología",
    "Creamos experiencias que",
    "reducen la fricción.",
    "Construimos productos digitales claros, ágiles y escalables, pensados para las personas y preparados para crecer.",
    "Nuestro enfoque"
  ],
  [
    slide3,
    "IA + Automatización",
    "Tecnología que mejora",
    "cómo trabajas.",
    "Integramos inteligencia artificial y automatización para transformar procesos complejos en experiencias más simples y eficientes.",
    "Ver soluciones"
  ]
]

const Flechas = () => {
  const swiper = useSwiper()
  const clase = "absolute z-30 top-1/2 flex size-12 -translate-y-1/2 cursor-pointer justify-center items-center rounded-full border border-white/30 bg-primary/70 text-xl text-white hover:bg-primary/30"
  return (
    <>
      <button className={`${clase} left-6`} onClick={() => swiper.slidePrev()}>
         ◀
      </button>
      <button className={`${clase} right-6`} onClick={() => swiper.slideNext()}>
        ▶
      </button>
    </>
  )
}


export const Banner = () => {
  return (
    <figure className="w-full h-64 md:h-144 overflow-hidden">
      <Swiper
        modules={[Autoplay, Pagination, EffectFade]}
        effect="fade"
        speed={900}
        autoplay={{ delay: 6000, disableOnInteraction: false }}
        pagination={{ clickable: true }}
        loop
        className="relative h-125 md:h-140 lg:h-155">

        {SLIDES.map(([imagen, etiqueta, titulo, destacado, descripcion, boton]) => (
          <SwiperSlide key={titulo}>
            <div className="relative h-full">
              <img src={imagen} alt="" className="absolute inset-0 h-full w-full object-cover" />
              <div className="relative z-10 mx-auto flex h-full max-w-7xl items-center px-12">
                <div className="bg-primary/80 text-white border border-white/25 max-w-lg rounded-3xl shadow-2xl backdrop-blur-md p-10">
                  <div className="mb-5 flex items-center gap-3 text-xs font-semibold uppercase text-accent">
                    <span className="h-px w-8 bg-accent" />{etiqueta}</div>
                  <h2 className="text-3xl font-bold md:text-4xl">
                    {titulo} <span className="block text-accent">{destacado}</span></h2>
                  <p>{descripcion}</p>
                  <div className="mt-8 flex gap-4">
                    <a href="#" className="bg-accent rounded-full px-5 py-3 font-semibold text-primary hover:-translate-y-0.5 transition">
                      {boton}</a>
                    <Link to="/contactenos" className="border border-white/25 rounded-full px-6 py-3 hover:bg-white/10 transition">
                      Contáctenos</Link>
                  </div>
                </div>
              </div>
            </div>
          </SwiperSlide>
        ))}
        <Flechas />
      </Swiper>
    </figure>
  )
}
