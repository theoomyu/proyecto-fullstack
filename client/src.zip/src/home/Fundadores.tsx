import Heading from "../components/Headings"
import fundador1 from "../assets/fundadores/elon_musk.jpg"
import fundador2 from "../assets/fundadores/sam_altman.jpg"
import fundador3 from "../assets/fundadores/jensen_huang.jpg"

export const Fundadores = () => {
    return (
        <section className="py-20">
            <div className="max-w-7xl mx-auto px-3">
                <Heading level={2} className="text-muted">Fundadores</Heading>
                <div className="grid md:grid-cols-3 gap-8">
                    <article className="bg-surface rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl hover:-translate-y-1 transition-all duration-300">
                        <figure className="mb-2 overflow-hidden">
                            <img src={fundador1} alt="" className="hover:scale-105 transition-transform duration-500"/>
                        </figure>
                        <div className="p-6">
                            <Heading level={3}>Elon Musk</Heading>
                            <p>Impulsa la ingeniería aeroespacial y automotriz global mediante cohetes reutilizables de SpaceX y vehículos eléctricos de Tesla.</p>
                            <p>Su constante desafío técnico redefine la movilidad terrestre, la conectividad satelital y el futuro de las misiones interplanetarias comerciales tripuladas.</p>
                        </div>
                    </article>
                    <article className="bg-surface rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl hover:-translate-y-1 transition-all duration-300">
                        <figure className="mb-2 overflow-hidden">
                            <img src={fundador2} alt=""  className="hover:scale-105 transition-transform duration-500"/>
                        </figure>
                        <div className="p-6">
                        <Heading level={3}>Sam Altman</Heading>
                        <p>Lidera la rápida evolución de la inteligencia artificial generativa como director de OpenAI, transformando la computación contemporánea.</p>
                        <p>Promueve herramientas de lenguaje masivas, orientando debates éticos sobre el trabajo digital y el desarrollo seguro hacia una inteligencia general.</p>
                        </div>
                    </article>
                    <article className="bg-surface rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl hover:-translate-y-1 transition-all duration-300">
                        <figure className="mb-2 overflow-hidden">
                            <img src={fundador3} alt=""  className="hover:scale-105 transition-transform duration-500"/>
                        </figure>
                        <div className="p-6">
                            <Heading level={3}>Jensen Huang</Heading>
                            <p>Transformó la industria del hardware gráfico en la base esencial del procesamiento masivo y la computación científica actual.</p>
                            <p>Desde Nvidia impulsa arquitecturas avanzadas de microchips que aceleran redes neuronales profundas, supercómputo global y nuevos centros de datos inteligentes.</p>
                        </div>
                    </article>
                </div>
            </div>
        </section>
    )
}
