import Heading from "../components/Headings"
import construimos from "../assets/construimos.jpg"
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"
import {
  faBuilding, faLaptopCode, faEarthAmericas } from "@fortawesome/free-solid-svg-icons"
import { Link } from "react-router"


export const Construimos = () => {
  return (
    <section className="py-20 bg-surface">
        <div className="max-w-7xl mx-auto px-3">
          <div className="grid md:grid-cols-2 gap-8">
            <div className="self-center">
              <div className="inline-flex border border-primary/30 bg-surface px-4 py-2 rounded-full text-muted/50 text-xs mb-8 gap-3 items-center">
              <span className="size-2 rounded-full bg-accent" />
              Software + IA con propósito</div>
              <Heading level={2}>
                Construimos productos que hacen que la IA <span className="text-accent">se sienta fácil</span>
              </Heading>
              <p>Diseñamos y desarrollamos experiencias digitales rápidas, claras y escalables para equipos que quieren pasar de una idea prometedora a un producto que las personas realmente usan.</p> 
              <div className="flex flex-col gap-3 sm:flex-row">
                <a href="#"
                  className="bg-primary text-background px-6 py-3 rounded-full hover:bg-secondary">Explorar servicios ↘</a>
                <Link to="/proyectos"
                  className="border border-primary/30 bg-background px-6 py-3 rounded-full hover:bg-surface">Ver proyectos</Link>
              </div>
              <div className="mt-12 grid grid-cols-3 gap-4 border-t border-foreground/10 pt-6">
                <div>
                  <FontAwesomeIcon icon={faBuilding} className="mb-3 size-10 rounded-full bg-accent/20 p-2.5 text-accent"/>
                  <p className="text-5xl font-semibold">50</p>
                  <p className="text-xs text-muted">Centros de desarrollo</p>
                </div>
                <div>
                  <FontAwesomeIcon icon={faLaptopCode} className="mb-3 size-10 rounded-full bg-accent/20 p-2.5 text-accent"/>
                  <p className="text-5xl font-semibold">260</p>
                  <p className="text-xs text-muted">Soluciones digitales integradas</p>
                </div>
                <div>
                  <FontAwesomeIcon icon={faEarthAmericas} className="mb-3 size-10 rounded-full bg-accent/20 p-2.5 text-accent"/>
                  <p className="text-5xl font-semibold">18</p>
                  <p className="text-xs text-muted">Países con presencia</p>
                </div>
              </div>
            </div>
            <div>
              <figure className="relative rounded-4xl overflow-hidden">
                <img src={construimos} alt="" />
                <div className="absolute inset-x-0 bottom-0 p-5 sm:p-7 
                      bg-black/60 backdrop-blur-sm text-background m-8
                      rounded-2xl border border-accent/30">
                 <div className="flex justify-between">         
                 <p className="text-xs uppercase tracking-widest">sistema / estado</p>
                  <div className="inline-flex border border-white/50 bg-accent px-2 py-1 rounded-full text-white/50 text-xs mb-8">Promoción</div>
                  </div>

                  <div className="flex justify-between items-end gap-5">
                    <div>
                      <p className="font-medium mb-0">Experiencias que reducen fricción.</p>
                      <p className="text-xs">Menos ornamentación. Más jerarquía, respuesta y claridad.</p>
                    </div>
                    <div className="grid size-12 place-items-center rounded-full bg-primary text-xl text-accent">
                      ↗ 
                    </div>
                  </div>
                  
                </div>
              </figure>
            </div>    
          </div>
        </div>
    </section>        
  )
}
