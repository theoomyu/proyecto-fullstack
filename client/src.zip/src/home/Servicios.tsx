import Heading from "../components/Headings"

export const Servicios = () => {
    return (
        <section className="bg-primary text-background py-20">
            <div className="max-w-7xl mx-auto py-4">
                <Heading level={2} className="border-s-4 border-accent ps-6 mt-1">Servicios</Heading>
                <p>Loki se fundó con la convicción de que la inteligencia artificial no debía ser una tecnología inalcanzable, sino una herramienta transformadora y accesible para empresas de todos los sectores. Comenzamos como un equipo unido por la curiosidad técnica, experimentando con los primeros modelos de lenguaje para resolver problemas cotidianos de programación y automatización de procesos.</p>
                <p>Con el tiempo, nuestra visión se expandió y evolucionamos hasta convertirnos en un laboratorio de desarrollo full-stack especializado. Hoy en día, diseñamos y construimos aplicaciones escalables desde cero, integrando arquitecturas de software robustas con soluciones de IA avanzadas. Nuestro viaje siempre ha estado impulsado por un único propósito: transformar ideas audaces en plataformas digitales inteligentes y preparadas para el futuro.</p>
            </div>
        </section>
    )
}
