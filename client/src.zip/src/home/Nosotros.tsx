import Heading from "../components/Headings"

export const Nosotros = () => {
  return (
    <section className="bg-surface py-20 md:py-24">
      <div className="max-w-7xl mx-auto px-3 lg:px-8">
        <div className="grid lg:grid-cols-[1fr_3fr] gap-8">
          <div>
            <div className="mb-4 text-sm font-medium uppercase text-primary">
              Quienes somos
            </div>
            <Heading level={2}>Nosotros</Heading>
            <p className="text-sm">
              Tecnología, ingeniería e inteligencia artificial para construir
              productos digitales con impacto real.
            </p>
          </div>
          <div>
            <p className="text-lg text-foreground/60 leading-7">Somos un equipo apasionado por la innovación tecnológica, dedicados al desarrollo de aplicaciones de software impulsadas por Inteligencia Artificial. Creemos que la IA no es solo el futuro, sino el motor presente que transforma radicalmente cómo las organizaciones escalan y evolucionan. Nuestra misión es diseñar soluciones digitales a medida, ágiles e inteligentes, que optimicen flujos de trabajo y resuelvan desafíos complejos con eficiencia. Desde la arquitectura de backend hasta la interfaz, integramos modelos generativos y automatizaciones para convertir ideas audaces en productos tangibles de alto impacto. Nos caracteriza nuestra enorme adaptabilidad y sólida excelencia técnica, creando un ecosistema tecnológico que potencia el crecimiento comercial de nuestros clientes, preparándolos estratégicamente para liderar en la nueva era digital verdaderamente inteligente.</p>
          </div>
        </div>
      </div>

    </section>
  )
}
