import Heading from "../components/Headings"

export interface EventoItem {
    id: string;
    foto: string;
    titulo: string;
    descripcion: string;
}

export const DATA_EVENTOS: EventoItem[] = [
    {
        id: "e1",
        foto: "/eventos/inteligencia_artificial.png",
        titulo: "Congreso Internacional de Inteligencia Artificial",
        descripcion: "Expertos globales debatirán sobre el futuro de la automatización avanzada y los modelos generativos aplicados a la industria moderna actual."
    },
    {
        id: "e2",
        foto: "/eventos/software_agile.png",
        titulo: "Cumbre de Desarrollo Software Ágile",
        descripcion: "Descubre metodologías disruptivas para optimizar flujos de código robustos, arquitectura escalable y colaboración eficiente entre equipos de desarrollo modernos."
    },
    {
        id: "e3",
        foto: "/eventos/innovacion_tecnologica.png",
        titulo: "Feria de Innovación Tecnológica Global",
        descripcion: "Presentación exclusiva de prototipos robóticos, gemelos digitales y sistemas inteligentes diseñados para transformar radicalmente la productividad de las organizaciones."
    },
    {
        id: "e4",
        foto: "/eventos/n8n.png",
        titulo: "Workshop de Automatización con N8N",
        descripcion: "Aprende talleres prácticos para conectar APIs empresariales, servicios en la nube y flujos de trabajo inteligentes sin escribir código redundante."
    }
]

export const Eventos = () => {
    return (
        <section className="py-20">
            <div className="max-w-7xl mx-auto px-3">
                <Heading level={2} className="text-muted">Eventos</Heading>
                <div className="grid md:grid-cols-4 gap-8">
                    {
                        DATA_EVENTOS.map(evento => (

                            <article key={evento.id} className="bg-surface rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl hover:-translate-y-1 transition-all duration-300">
                                <figure className="mb-2 overflow-hidden">
                                    <img src={evento.foto} alt="" className="hover:scale-105 transition-transform duration-500" />
                                </figure>
                                <div className="p-6">
                                    <Heading level={3}>{evento.titulo}</Heading>
                                    <p>{evento.descripcion}</p>
                                </div>
                            </article>
                        ))
                    }
                </div>
            </div>
        </section>
    )
}
