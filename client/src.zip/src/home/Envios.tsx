import Heading from "../components/Headings"
import { QueryClient, QueryClientProvider, useQuery } from "@tanstack/react-query"


export interface Envio {
  idempresaenvio: number;
  nombre: string;
  telefono: string;
  sitio_web: string;
  latitud: number;
  longitud: number;
}

const queryClient = new QueryClient()

const EnviosContent = () => {
  const { data = [], isPending } = useQuery<Envio[]>({
    queryKey: ["Envios"],
    queryFn: () => fetch("https://servicios.campus.pe/envios.php").then(r => r.json())
  })
  return (
    <section className="py-20 bg-surface">
      <div className="max-w-7xl mx-auto px-3">
        <Heading level={2} className="text-muted">Empresas de envíos</Heading>
        {isPending ? (
          <p>Cargando...</p>
        ) :  (
          <table className="w-full overflow-hidden bg-background rounded-2xl text-left text-sm shadow-sm">
            <thead className="bg-primary text-background">
              <tr>
                {["Código","Empresa", "Teléfono", "Sitio Web", "Latitud", "Longitud"].map(h =>(
                  <th className="px-5 py-4 text-xs font-bold uppercase"
                    key={h}>{h}</th>
                ))
                }
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
                {data.map(({idempresaenvio, nombre, telefono, sitio_web, latitud, longitud}) =>(
                  <tr key={idempresaenvio}
                    className="hover:bg-surface-subtle transition-colors">
                    <td className="px-5 py-4 font-semibold text-primary">{idempresaenvio}</td>
                    <td className="px-5 py-4 font-semibold text-primary">{nombre}</td>
                    <td className="px-5 py-4 font-semibold text-primary">{telefono}</td>
                    <td className="px-5 py-4 font-semibold text-primary">
                      <a href={sitio_web} target="_blank">{sitio_web}</a>
                      </td>
                    <td className="px-5 py-4 font-semibold text-primary">{latitud}</td>
                    <td className="px-5 py-4 font-semibold text-primary">{longitud}</td>
                  </tr>
                ))}
            </tbody>
          </table>
        )}
      </div>
    </section>
  )
}

export const Envios = () => {
  return (
    <QueryClientProvider client={queryClient}>
      <EnviosContent />
    </QueryClientProvider>
  )
}
