import { Link } from "react-router"
import Heading from "../components/Headings"

export const MainHeader = () => {
    return (
        <header className="py-6 bg-surface/60 backdrop-blur-xl sticky top-0 z-1000 border-b-2 border-border">
            <div className="max-w-7xl mx-auto px-3">
                <Heading level={1} className="mb-0!"><Link to="/">Loki.<span className="text-accent">AI</span></Link></Heading>
                <p>Escribimos el código del futuro, impulsamos tu presente</p>
            </div>
        </header>
    )
}
