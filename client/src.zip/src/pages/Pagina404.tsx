export const Pagina404 = () => {
  return (
    <div>Pagina404</div>
  )
}
