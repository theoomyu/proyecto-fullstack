import Heading from "../components/Headings"

export const Proyectos = () => {
  return (
    <Heading level={1}>Proyectos</Heading>
  )
}
