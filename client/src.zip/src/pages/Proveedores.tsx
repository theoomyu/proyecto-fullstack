import Heading from "../components/Headings"

export const Proveedores = () => {
  return (
    <Heading level={1}>Proveedores</Heading>
  )
}
