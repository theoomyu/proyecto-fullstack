import Heading from "../components/Headings"

export const Contactenos = () => {
  return (
    <Heading level={1}>Contactenos</Heading>
  )
}
