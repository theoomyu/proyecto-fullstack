import { Banner } from "../home/Banner"
import { Construimos } from "../home/Construimos"
import { Empresa } from "../home/Empresa"
import { Envios } from "../home/Envios"
import { Eventos } from "../home/Eventos"
import { Fundadores } from "../home/Fundadores"
import { Nosotros } from "../home/Nosotros"
import { Servicios } from "../home/Servicios"

export const Home = () => {
  return (
    <>
        <Banner />
        <Nosotros />
        <Fundadores />
        <Empresa />
        <Construimos/>
        <Servicios />
        <Eventos />
        <Envios />
    </>
  )
}
