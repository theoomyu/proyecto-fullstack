import Heading from "../components/Headings"

export const Empleados = () => {
  return (
    <Heading level={1}>Empleados</Heading>
  )
}
